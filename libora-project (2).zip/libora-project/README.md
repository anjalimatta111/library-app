# Libora — College Library App

A premium, fully interactive front-end for a college library: catalog search, borrowing/returns/renewals/reservations, an interactive seat map, an AI-style library assistant, notifications, a student profile, and a full admin dashboard with CRUD over books, users, seats and reservations.

## Project structure

```
libora-project/
├── index.html          # Page structure + markup for every screen
├── css/
│   └── styles.css       # All styling (design tokens, layout, components)
├── js/
│   └── app.js            # All app logic: data, state, rendering, interactions
├── assets/
│   └── bookshelf-tile.svg   # Tiled bookshelf illustration used as the app-wide background
└── README.md
```

## Running it

No build step, no dependencies. Because the page loads `css/styles.css` and `js/app.js` as external files (rather than being inlined), open it through a local server rather than double-clicking the file, so the browser is allowed to fetch those relative paths:

```bash
cd libora-project
python3 -m http.server 8080
# then open http://localhost:8080 in your browser
```

Any static server works (`npx serve`, VS Code's "Live Server" extension, etc.) — the app itself is pure HTML/CSS/JS with two external font families loaded from Google Fonts.

## Demo accounts

| Role    | Email                    | Password    |
|---------|---------------------------|-------------|
| Student | student@ashcombe.edu     | student123  |
| Admin   | admin@ashcombe.edu       | admin123    |

You can also sign up as a new Student or Admin from the login screen.

## Important: no real backend

This was built as a front-end prototype. **All data (users, books, borrow records, reservations, seats, notifications) lives in memory in `js/app.js`** and resets whenever the page reloads. There is no database and no server — everything is simulated in the browser so every feature is genuinely clickable and functional, but nothing persists.

To make it production-ready, you'd wire `js/app.js`'s data layer (the `DB` object and the functions that mutate it — `borrowBook`, `returnBook`, `renewBook`, `reserveBook`, `confirmSeatReserve`, the admin CRUD functions, etc.) up to a real backend/database and authentication provider of your choice.

## Design system

- **Fonts:** Lora (headings), Inter (UI text), IBM Plex Mono (due-date stamps, ISBNs, seat codes — a nod to old library card-catalog stamps)
- **Palette:** dark navy background with brighter blue, brass/gold, green, amber and red accents — defined as CSS custom properties at the top of `css/styles.css` (`:root`), so re-theming mostly means editing that block
- **Background art:** the bookshelf illustration in `assets/bookshelf-tile.svg` tiles behind every page at low opacity; a second, larger inline illustration (in `index.html`, inside `.auth-side`) decorates the login screen

## Notable implementation details

- `js/app.js` is organized top-to-bottom as: icon library → seed data (books/seats/users/notifications) → session/UI state → auth → navigation → each page's render function → modal helpers → admin dashboard → the rule-based AI assistant (`answerAiQuery`, which matches keywords against the live `DB` rather than calling an external AI API)
- All book covers are CSS-gradient placeholders keyed by category (`COVER_GRADIENTS` in `app.js`) rather than real cover images
- Toasts, empty states and inline form validation are implemented throughout rather than left as TODOs
