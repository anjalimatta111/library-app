/* ============================================================
   LIBORA — Ashcombe College Library
   Self-contained front-end prototype. All data lives in memory
   for this session (no external backend is connected).
   ============================================================ */

/* ---------------- ICONS ---------------- */
const ICONS = {
  dashboard: `<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/></svg>`,
  search: `<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>`,
  library: `<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>`,
  seat: `<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 10V6a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v4"/><path d="M4 14h16v6H4z"/><path d="M4 20v-2M20 20v-2"/></svg>`,
  info: `<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>`,
  profile: `<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4.5 5-6 8-6s6.5 1.5 8 6"/></svg>`,
  admin: `<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2 3 6v6c0 5 3.8 8.7 9 10 5.2-1.3 9-5 9-10V6l-9-4Z"/></svg>`,
  book: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>`,
  clock: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>`,
  check: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 6 9 17l-5-5"/></svg>`,
  x: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6 6 18M6 6l12 12"/></svg>`,
  plus: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>`,
  edit: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>`,
  trash: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>`,
  mappin: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>`,
  refresh: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 3v6h-6"/></svg>`,
  bookmark: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21 12 16l-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2Z"/></svg>`,
  wifi: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13a10 10 0 0 1 14 0M8.5 16.5a5 5 0 0 1 7 0M12 20h.01"/></svg>`,
  print: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9V2h12v7"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 14h12v8H6z"/></svg>`,
  coffee: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 8h1a4 4 0 1 1 0 8h-1"/><path d="M3 8h14v9a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4Z"/><path d="M6 2v3M10 2v3M14 2v3"/></svg>`,
  users: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>`,
  phone: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3.1-8.7A2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.3 1.8.6 2.7a2 2 0 0 1-.5 2.1L8 9.7a16 16 0 0 0 6 6l1.2-1.2a2 2 0 0 1 2.1-.5c.9.3 1.8.5 2.7.6a2 2 0 0 1 1.7 2Z"/></svg>`,
  mail: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 6-10 7L2 6"/></svg>`,
  alert: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4M12 17h.01"/></svg>`,
};

/* ---------------- DATA ---------------- */
const CATEGORIES = ["Computer Science","Mathematics","Physics","Literature","Business","Engineering","Biology","History","Psychology","Economics"];
const COVER_GRADIENTS = {
  "Computer Science": "linear-gradient(150deg,#1E4676,#0B1F3F)",
  "Mathematics": "linear-gradient(150deg,#2B5FA0,#122A50)",
  "Physics": "linear-gradient(150deg,#3D6EA5,#16324F)",
  "Literature": "linear-gradient(150deg,#8C6A38,#4E3C22)",
  "Business": "linear-gradient(150deg,#2E7D5B,#12402C)",
  "Engineering": "linear-gradient(150deg,#4B5563,#1F2937)",
  "Biology": "linear-gradient(150deg,#3F8768,#144531)",
  "History": "linear-gradient(150deg,#A9824C,#5C4423)",
  "Psychology": "linear-gradient(150deg,#6B5B95,#2E2648)",
  "Economics": "linear-gradient(150deg,#B3432B,#5C1F13)"
};

function initials(str){ return str.split(" ").map(w=>w[0]).slice(0,2).join("").toUpperCase(); }

let DB = {
  users: [
    {id:"u-admin", name:"Margaret Holt", email:"admin@ashcombe.edu", password:"admin123", role:"admin", dept:"Library Administration", idval:"STAFF-0012", joined:"2019-08-01"},
    {id:"u-student", name:"Jordan Blake", email:"student@ashcombe.edu", password:"student123", role:"student", dept:"Computer Science", idval:"ASC-2024-0451", joined:"2024-08-20"},
    {id:"u-2", name:"Priya Nair", email:"priya.nair@ashcombe.edu", password:"pass123", role:"student", dept:"Economics", idval:"ASC-2023-0219", joined:"2023-08-14"},
    {id:"u-3", name:"Sam Ortega", email:"sam.ortega@ashcombe.edu", password:"pass123", role:"student", dept:"Physics", idval:"ASC-2022-0087", joined:"2022-08-10"},
  ],
  books: [],
  borrows: [],
  reservations: [],
  seats: [],
  seatReservations: [],
  notifications: [],
};

function seedBooks(){
  const raw = [
    ["Structures & Algorithms in Practice","Elena Kowalski","Computer Science","978-1-4302-1234-5","A rigorous, example-driven tour of core data structures and algorithm design, from hash tables to graph traversal, with complexity analysis throughout.","CS",1,4],
    ["Introduction to Database Systems","Rajiv Menon","Computer Science","978-0-13-608326-9","Covers relational theory, SQL, normalization, transactions and modern distributed storage engines for undergraduate and graduate courses.","CS",1,2],
    ["Operating Systems: Concepts & Design","Harold Feinberg","Computer Science","978-0-470-12872-5","Explains process scheduling, memory management, file systems and concurrency with case studies from Unix-like kernels.","CS",1,0],
    ["Linear Algebra and Its Applications","Marcus Whitfield","Mathematics","978-0-321-98238-4","A geometry-first treatment of vector spaces, eigenvalues and linear transformations built for engineering and science majors.","MA",2,5],
    ["Real Analysis: A First Course","Ines Duval","Mathematics","978-1-4704-1099-8","Careful construction of limits, continuity and integration theory with proofs suitable for a first rigorous analysis sequence.","MA",1,1],
    ["Probability & Statistical Inference","David Achebe","Mathematics","978-0-13-411529-3","Foundational probability theory paired with estimation, hypothesis testing and regression, with worked applied examples.","MA",2,0],
    ["Classical Mechanics",'Werner Aldrich',"Physics","978-0-201-65702-9","A modern reworking of Newtonian and Lagrangian mechanics with problem sets drawn from orbital and rigid-body dynamics.","PH",1,3],
    ["Introduction to Quantum Theory","Sofia Lindqvist","Physics","978-0-13-805326-0","Builds quantum mechanics from wave-particle duality through operators, spin and the hydrogen atom.","PH",1,0],
    ["Thermodynamics and Statistical Mechanics","Peter Voss","Physics","978-1-107-66910-2","Bridges macroscopic thermodynamic law with microscopic statistical foundations, entropy and phase transitions.","PH",1,2],
    ["The Penrose Letters","Amara Osei","Literature","978-0-345-80987-2","A quietly devastating epistolary novel following two estranged siblings rebuilding trust across a decade of letters.","LI",3,6],
    ["Modern Poetics: An Anthology","Clara Bregman","Literature","978-0-393-93023-1","A curated survey of twentieth-century poetic movements, from imagism to confessional verse, with critical commentary.","LI",2,4],
    ["Shakespeare in Context","Thomas Ryeland","Literature","978-0-19-928765-3","Places the major tragedies and comedies within Elizabethan politics, theatre practice and print culture.","LI",1,0],
    ["Principles of Corporate Finance","Diane Castellanos","Business","978-1-259-91892-9","The standard treatment of valuation, capital structure, risk and investment decisions used across MBA-track courses.","BU",2,3],
    ["Strategic Marketing Management","Owen Farraday","Business","978-0-273-71958-7","Frameworks for market positioning, brand strategy and competitive analysis grounded in contemporary case studies.","BU",1,1],
    ["Operations & Supply Chain Strategy","Naledi Botha","Business","978-1-118-93372-4","Examines lean production, logistics network design and supply chain risk through global manufacturing cases.","BU",1,0],
    ["Materials Science for Engineers","Klaus Reinholt","Engineering","978-0-13-446138-9","Connects atomic bonding and microstructure to the mechanical, thermal and electrical properties engineers rely on.","EN",1,2],
    ["Fundamentals of Fluid Mechanics","Gabriela Mott","Engineering","978-1-119-08070-1","A problem-oriented introduction to fluid statics, viscous flow and dimensional analysis for mechanical engineers.","EN",1,0],
    ["Digital Signal Processing","Ahmed Zafar","Engineering","978-0-13-394338-6","Covers sampling theory, filter design and the Fourier and z-transforms with MATLAB-based exercises.","EN",1,3],
    ["Molecular Biology of the Cell (Concise)","Rosalind Achterberg","Biology","978-0-8153-4464-3","A condensed but rigorous account of cell structure, gene expression and signalling for undergraduate biology.","BI",2,4],
    ["Genetics: Principles and Analysis","Felix Okonjo","Biology","978-1-284-12631-9","Mendelian and molecular genetics united through problem-based chapters on inheritance and gene regulation.","BI",1,0],
    ["Ecology and the Biosphere","Ines Duval","Biology","978-0-321-61852-9","Explores population dynamics, ecosystem energy flow and conservation biology through global field studies.","BI",1,1],
    ["The Making of the Modern World","Isabelle Konrath","History","978-0-393-92985-3","Traces industrialization, empire and revolution across three centuries with an emphasis on global connections.","HI",1,0],
    ["Empires and Their Discontents","Benedict Solano","History","978-0-674-97534-8","A comparative study of imperial decline, from Rome to the twentieth century, and the movements that hastened it.","HI",1,2],
    ["Cognitive Psychology: Mind and Brain","Yuki Tanaka","Psychology","978-0-13-421315-4","Integrates behavioral experiments with neuroscience to explain memory, attention, language and decision-making.","PS",2,3],
    ["Developmental Psychology Across the Lifespan","Marisol Vega","Psychology","978-1-4292-3719-2","Follows human development from infancy to late adulthood through longitudinal research and theory.","PS",1,0],
    ["Principles of Microeconomics","Chidi Okafor","Economics","978-1-337-09598-7","Covers consumer choice, market structure and welfare economics with real-market applications throughout.","EC",2,5],
    ["Macroeconomics and Global Policy","Helena Bright","Economics","978-0-19-878064-7","Examines growth, inflation and monetary policy through the lens of post-2008 global economic events.","EC",1,1],
    ["Behavioral Economics: Judgment and Choice","Andres Villalobos","Economics","978-0-691-16151-9","Surveys the cognitive biases that shape economic decisions, blending psychology with formal economic modelling.","EC",1,0],
  ];
  DB.books = raw.map((r,i)=>({
    id:"b-"+(i+1),
    title:r[0], author:r[1], category:r[2], isbn:r[3], description:r[4],
    glyph:r[5], rack:"R-"+(3+Math.floor(i/4)), shelf:String.fromCharCode(65+(i%5)),
    total:r[6], available:r[7]
  }));
}

function seedSeats(){
  const zones = [
    {zone:"Reading Hall", count:30, prefix:"RH"},
    {zone:"Silent Study Zone", count:20, prefix:"SZ"},
    {zone:"Group Study Pods", count:16, prefix:"GP"},
    {zone:"Computer Lab", count:20, prefix:"CL"},
  ];
  let seats = [];
  zones.forEach(z=>{
    for(let i=1;i<=z.count;i++){
      seats.push({
        id: z.prefix+"-"+String(i).padStart(2,"0"),
        zone: z.zone,
        occupied: Math.random() < 0.38,
        reservedBy: null
      });
    }
  });
  // guarantee a few pre-reserved-by-others for realism (not the demo user)
  DB.seats = seats;
}

function seedNotifications(){
  DB.notifications = [
    {id:"n1", userId:"u-student", type:"due", title:"Book due soon", msg:"“Structures & Algorithms in Practice” is due in 2 days.", date: daysAgoISO(0), read:false},
    {id:"n2", userId:"u-student", type:"info", title:"Welcome to Libora", msg:"Your account is set up. Explore the catalog to borrow your first book.", date: daysAgoISO(3), read:true},
  ];
}

function daysAgoISO(n){ const d=new Date(); d.setDate(d.getDate()-n); return d.toISOString(); }
function addDaysISO(n){ const d=new Date(); d.setDate(d.getDate()+n); return d.toISOString(); }
function fmtDate(iso){ const d=new Date(iso); return d.toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'}); }
function fmtDateShort(iso){ const d=new Date(iso); return d.toLocaleDateString('en-US',{month:'short',day:'numeric'}); }
function daysBetween(a,b){ return Math.ceil((new Date(b)-new Date(a))/(1000*60*60*24)); }
function uid(prefix){ return prefix+"-"+Math.random().toString(36).slice(2,9); }

seedBooks(); seedSeats(); seedNotifications();

/* ---------------- SESSION / GLOBAL STATE ---------------- */
let session = { user: null };
let ui = {
  view: "dashboard",
  catalogFilters: { q:"", category:"All", availability:"All" },
  myLibraryTab: "borrowed",
  adminTab: "overview",
  notifOpen: false,
  aiOpen: false,
  aiHistory: [],
};

const LIBRARY_HOURS = { openHour: 6.5, closeHour: 23 }; // 6:30am - 11:00pm

function isLibraryOpen(){
  const now = new Date();
  const h = now.getHours() + now.getMinutes()/60;
  return h >= LIBRARY_HOURS.openHour && h < LIBRARY_HOURS.closeHour;
}
function nextChangeLabel(){
  const open = isLibraryOpen();
  return open ? "Closes at 11:00 PM" : "Opens at 6:30 AM";
}

/* ---------------- TOASTS ---------------- */
function toast(msg, type="default"){
  const wrap = document.getElementById("toast-wrap");
  const el = document.createElement("div");
  el.className = "toast "+type;
  const ic = type==="success" ? ICONS.check : type==="error" ? ICONS.x : ICONS.info;
  el.innerHTML = `<span style="display:flex">${ic}</span><span>${msg}</span>`;
  wrap.appendChild(el);
  setTimeout(()=>{ el.style.opacity="0"; el.style.transition="opacity .3s"; setTimeout(()=>el.remove(),300); }, 3200);
}

/* ---------------- AUTH ---------------- */
function showLogin(){ document.getElementById("login-view").style.display="block"; document.getElementById("signup-view").style.display="none"; }
function showSignup(){ document.getElementById("login-view").style.display="none"; document.getElementById("signup-view").style.display="block"; }

function setupRoleToggle(id){
  const wrap = document.getElementById(id);
  wrap.querySelectorAll("button").forEach(btn=>{
    btn.onclick = ()=>{
      wrap.querySelectorAll("button").forEach(b=>b.classList.remove("active"));
      btn.classList.add("active");
      if(id==="signup-role-toggle"){
        const role = btn.dataset.role;
        document.getElementById("signup-id-label").textContent = role==="admin" ? "Staff ID" : "Student ID";
        document.getElementById("signup-idval").placeholder = role==="admin" ? "STAFF-0045" : "ASC-2027-0451";
      }
    };
  });
}
setupRoleToggle("login-role-toggle");
setupRoleToggle("signup-role-toggle");

function getActiveRole(toggleId){
  return document.querySelector("#"+toggleId+" button.active").dataset.role;
}

function handleLogin(){
  const role = getActiveRole("login-role-toggle");
  const email = document.getElementById("login-email").value.trim().toLowerCase();
  const pass = document.getElementById("login-password").value;
  const errEl = document.getElementById("login-error");
  errEl.classList.remove("show");

  if(!email || !pass){
    errEl.textContent = "Please enter both email and password.";
    errEl.classList.add("show");
    return;
  }
  const user = DB.users.find(u=>u.email.toLowerCase()===email);
  if(!user || user.password !== pass){
    errEl.textContent = "We couldn't find a matching account. Check your email and password.";
    errEl.classList.add("show");
    return;
  }
  if(user.role !== role){
    errEl.textContent = `This account is registered as ${user.role==='admin'?'Admin / Librarian':'Student'}. Switch the role tab above to sign in.`;
    errEl.classList.add("show");
    return;
  }
  session.user = user;
  enterApp();
}

function handleSignup(){
  const role = getActiveRole("signup-role-toggle");
  const name = document.getElementById("signup-name").value.trim();
  const email = document.getElementById("signup-email").value.trim().toLowerCase();
  const idval = document.getElementById("signup-idval").value.trim();
  const dept = document.getElementById("signup-dept").value.trim();
  const pass = document.getElementById("signup-password").value;
  const errEl = document.getElementById("signup-error");
  errEl.classList.remove("show");

  if(!name || !email || !idval || !dept || !pass){
    errEl.textContent = "Please fill in every field to create your account.";
    errEl.classList.add("show");
    return;
  }
  if(!/^\S+@\S+\.\S+$/.test(email)){
    errEl.textContent = "Enter a valid email address.";
    errEl.classList.add("show");
    return;
  }
  if(pass.length < 6){
    errEl.textContent = "Password should be at least 6 characters.";
    errEl.classList.add("show");
    return;
  }
  if(DB.users.some(u=>u.email.toLowerCase()===email)){
    errEl.textContent = "An account with this email already exists. Try signing in instead.";
    errEl.classList.add("show");
    return;
  }
  const newUser = { id: uid("u"), name, email, password:pass, role, dept, idval, joined: new Date().toISOString() };
  DB.users.push(newUser);
  session.user = newUser;
  toast("Account created — welcome to Libora!", "success");
  enterApp();
}

function handleLogout(){
  session.user = null;
  document.getElementById("app-screen").style.display = "none";
  document.getElementById("auth-screen").style.display = "flex";
  document.getElementById("login-email").value = "";
  document.getElementById("login-password").value = "";
  showLogin();
}

function enterApp(){
  document.getElementById("auth-screen").style.display = "none";
  document.getElementById("app-screen").style.display = "block";
  ui.view = session.user.role === "admin" ? "admin" : "dashboard";
  buildSidebar();
  buildMobileNav();
  renderTopbarUser();
  navigate(ui.view);
}

/* ---------------- NAVIGATION / SIDEBAR ---------------- */
const STUDENT_NAV = [
  {view:"dashboard", label:"Dashboard", icon:"dashboard"},
  {view:"catalog", label:"Search Books", icon:"search"},
  {view:"mylibrary", label:"My Library", icon:"library"},
  {view:"seatmap", label:"Seat Map", icon:"seat"},
  {view:"overview", label:"Library Info", icon:"info"},
];
const ADMIN_NAV = [
  {view:"admin", label:"Admin Dashboard", icon:"dashboard"},
  {view:"catalog", label:"Browse Catalog", icon:"search"},
  {view:"seatmap", label:"Seat Map", icon:"seat"},
  {view:"overview", label:"Library Info", icon:"info"},
];

function buildSidebar(){
  const nav = session.user.role === "admin" ? ADMIN_NAV : STUDENT_NAV;
  const html = nav.map(n=>`
    <div class="nav-item" data-view="${n.view}" onclick="navigate('${n.view}')">${ICONS[n.icon]}<span>${n.label}</span></div>
  `).join("");
  document.getElementById("sidebar-nav").innerHTML = `<div class="nav-group">${html}<div class="nav-item" data-view="profile" onclick="navigate('profile')">${ICONS.profile}<span>Profile</span></div></div>`;
}

function buildMobileNav(){
  const nav = (session.user.role === "admin" ? ADMIN_NAV.slice(0,4) : STUDENT_NAV.slice(0,4));
  document.getElementById("mobile-nav").innerHTML = nav.map(n=>`
    <div class="m-item" data-view="${n.view}" onclick="navigate('${n.view}')">${ICONS[n.icon]}<span>${n.label.split(' ')[0]}</span></div>
  `).join("") + `<div class="m-item" data-view="profile" onclick="navigate('profile')">${ICONS.profile}<span>Profile</span></div>`;
}

function renderTopbarUser(){
  document.getElementById("side-avatar").textContent = initials(session.user.name);
  document.getElementById("side-name").textContent = session.user.name;
  document.getElementById("side-role").textContent = session.user.role === "admin" ? "Librarian / Admin" : session.user.dept;
  document.getElementById("topbar-avatar").textContent = initials(session.user.name);
}

function navigate(view){
  ui.view = view;
  document.querySelectorAll(".nav-item, .m-item").forEach(el=>{
    el.classList.toggle("active", el.dataset.view === view);
  });
  ui.notifOpen = false;
  document.getElementById("notif-panel").classList.remove("show");
  renderView();
  window.scrollTo(0,0);
}

function topbarSearch(){
  const q = document.getElementById("topbar-search-input").value.trim();
  ui.catalogFilters.q = q;
  navigate("catalog");
}

/* ---------------- MASTER RENDER ---------------- */
function renderView(){
  const c = document.getElementById("content");
  refreshNotifBadge();
  switch(ui.view){
    case "dashboard": c.innerHTML = renderDashboard(); break;
    case "catalog": c.innerHTML = renderCatalog(); attachCatalogEvents(); break;
    case "mylibrary": c.innerHTML = renderMyLibrary(); break;
    case "seatmap": c.innerHTML = renderSeatMap(); break;
    case "overview": c.innerHTML = renderOverview(); break;
    case "profile": c.innerHTML = renderProfile(); break;
    case "admin": c.innerHTML = renderAdmin(); break;
    default: c.innerHTML = renderDashboard();
  }
}

/* ---------------- DASHBOARD ---------------- */
function renderDashboard(){
  const u = session.user;
  const totalBooks = DB.books.reduce((s,b)=>s+b.total,0);
  const availBooks = DB.books.reduce((s,b)=>s+b.available,0);
  const totalSeats = DB.seats.length;
  const availSeats = DB.seats.filter(s=>!s.occupied).length;
  const open = isLibraryOpen();

  const myBorrows = DB.borrows.filter(b=>b.userId===u.id && b.status!=="returned");
  const overdue = myBorrows.filter(b=>new Date(b.dueDate) < new Date());
  const myReservations = DB.reservations.filter(r=>r.userId===u.id && r.status!=="cancelled" && r.status!=="fulfilled");

  const hour = new Date().getHours();
  const greet = hour<12?"Good morning":hour<17?"Good afternoon":"Good evening";

  return `
    <div class="page-head">
      <div><h1>${greet}, ${u.name.split(' ')[0]}.</h1><p class="sub">Here's what's happening at the library today.</p></div>
    </div>

    <div class="status-strip">
      <div class="left">
        <span class="status-pill ${open?'open':'closed'}"><span class="dot"></span>${open?'Library Open':'Library Closed'}</span>
        <div class="msg"><b>Ashcombe College Library</b><span>${nextChangeLabel()}</span></div>
      </div>
      <div class="timing"><span>Today's hours</span><b>6:30 AM – 11:00 PM</b></div>
    </div>

    <div class="stat-grid">
      <div class="card stat-card"><div class="top"><div class="stat-icon" style="background:var(--navy-100);color:var(--navy-700);">${ICONS.book}</div></div><b>${totalBooks.toLocaleString()}</b><span>Total books</span></div>
      <div class="card stat-card"><div class="top"><div class="stat-icon" style="background:var(--green-bg);color:var(--green);">${ICONS.check}</div></div><b>${availBooks.toLocaleString()}</b><span>Available now</span></div>
      <div class="card stat-card"><div class="top"><div class="stat-icon" style="background:var(--amber-bg);color:var(--amber);">${ICONS.seat}</div></div><b>${availSeats}/${totalSeats}</b><span>Seats available</span></div>
      <div class="card stat-card"><div class="top"><div class="stat-icon" style="background:${overdue.length?'var(--red-bg)':'var(--navy-100)'};color:${overdue.length?'var(--red)':'var(--navy-700)'};">${ICONS.clock}</div></div><b>${myBorrows.length}</b><span>${overdue.length? overdue.length+' overdue' : 'Currently borrowed'}</span></div>
    </div>

    <div class="section-title">Quick actions</div>
    <div class="quick-actions">
      <div class="card qa-btn" onclick="navigate('catalog')"><div class="ic">${ICONS.search}</div><div><b>Find a book</b><br><span>Search the full catalog</span></div></div>
      <div class="card qa-btn" onclick="navigate('seatmap')"><div class="ic">${ICONS.seat}</div><div><b>Reserve a seat</b><br><span>${availSeats} open right now</span></div></div>
      <div class="card qa-btn" onclick="navigate('mylibrary')"><div class="ic">${ICONS.library}</div><div><b>My Library</b><br><span>Borrowed & reserved items</span></div></div>
      <div class="card qa-btn" onclick="toggleAiPanel()"><div class="ic">${ICONS.info}</div><div><b>Ask the assistant</b><br><span>Get instant answers</span></div></div>
    </div>

    <div class="two-col" style="margin-top:30px;">
      <div class="card pad">
        <h3 style="font-size:16px;margin-bottom:14px;">Your borrowed books</h3>
        ${myBorrows.length ? myBorrows.slice(0,4).map(b=>{
          const book = DB.books.find(x=>x.id===b.bookId);
          const isOver = new Date(b.dueDate) < new Date();
          return `<div class="list-row">
            <div class="mini-cover" style="background:${COVER_GRADIENTS[book.category]}"><span class="g">${book.glyph}</span></div>
            <div style="flex:1;min-width:0;"><b style="font-size:13.5px;display:block;">${book.title}</b><span style="font-size:12px;color:var(--ink-soft);">${book.author}</span></div>
            <span class="stamp ${isOver?'overdue':'due'}">${isOver?'OVERDUE':'DUE'} ${fmtDateShort(b.dueDate)}</span>
          </div>`;
        }).join("") : `<div class="empty-state" style="padding:26px 10px;">${ICONS.book}<b>No active borrows</b><span style="font-size:12.5px;">Browse the catalog to borrow your first book.</span></div>`}
      </div>
      <div class="card pad">
        <h3 style="font-size:16px;margin-bottom:14px;">Reservations</h3>
        ${myReservations.length ? myReservations.slice(0,4).map(r=>{
          const book = DB.books.find(x=>x.id===r.bookId);
          return `<div class="list-row">
            <div class="mini-cover" style="background:${COVER_GRADIENTS[book.category]}"><span class="g">${book.glyph}</span></div>
            <div style="flex:1;min-width:0;"><b style="font-size:13.5px;display:block;">${book.title}</b><span style="font-size:12px;color:var(--ink-soft);">Queue position ${r.queuePos||1}</span></div>
            <span class="status-tag ${r.status}">${r.status}</span>
          </div>`;
        }).join("") : `<div class="empty-state" style="padding:26px 10px;">${ICONS.bookmark}<b>No reservations</b><span style="font-size:12.5px;">Reserve a book when it's checked out.</span></div>`}
      </div>
    </div>
  `;
}

/* ---------------- CATALOG ---------------- */
function renderCatalog(){
  const f = ui.catalogFilters;
  let books = DB.books.filter(b=>{
    const q = f.q.toLowerCase();
    const matchQ = !q || b.title.toLowerCase().includes(q) || b.author.toLowerCase().includes(q) || b.isbn.includes(q);
    const matchCat = f.category==="All" || b.category===f.category;
    const matchAvail = f.availability==="All" || (f.availability==="Available" ? b.available>0 : b.available===0);
    return matchQ && matchCat && matchAvail;
  });

  return `
    <div class="page-head"><div><h1>Search the catalog</h1><p class="sub">${DB.books.length} titles across ${CATEGORIES.length} subjects</p></div></div>
    <div class="filter-bar">
      <div class="search-field">${ICONS.search}<input id="catalog-q" placeholder="Title, author or ISBN…" value="${f.q}"></div>
      <select id="catalog-category">
        <option ${f.category==='All'?'selected':''}>All</option>
        ${CATEGORIES.map(c=>`<option ${f.category===c?'selected':''}>${c}</option>`).join("")}
      </select>
      <select id="catalog-availability">
        <option ${f.availability==='All'?'selected':''}>All</option>
        <option ${f.availability==='Available'?'selected':''}>Available</option>
        <option ${f.availability==='Unavailable'?'selected':''}>Unavailable</option>
      </select>
    </div>
    <p class="sub" style="margin-bottom:14px;">${books.length} result${books.length!==1?'s':''}</p>
    ${books.length ? `<div class="book-grid">${books.map(bookCardHtml).join("")}</div>` :
    `<div class="empty-state">${ICONS.search}<b>No books match your search</b><span>Try a different title, author or filter.</span></div>`}
  `;
}
function bookCardHtml(b){
  return `<div class="book-card" onclick="openBookDetail('${b.id}')">
    <div class="book-cover" style="background:${COVER_GRADIENTS[b.category]}"><div class="spine"></div><div class="glyph">${b.title.split(' ').slice(0,4).join(' ')}</div></div>
    <div class="book-body">
      <span class="cat">${b.category}</span>
      <h4>${b.title}</h4>
      <span class="auth">${b.author}</span>
      <div class="avail-row">
        <span class="avail-tag ${b.available>0?'yes':'no'}">${b.available>0? b.available+' available':'Checked out'}</span>
        <span class="rack-tag">${b.rack}·${b.shelf}</span>
      </div>
    </div>
  </div>`;
}
function attachCatalogEvents(){
  const qEl = document.getElementById("catalog-q");
  if(!qEl) return;
  qEl.oninput = e=>{ ui.catalogFilters.q = e.target.value; renderCatalogListOnly(); };
  document.getElementById("catalog-category").onchange = e=>{ ui.catalogFilters.category = e.target.value; renderView(); };
  document.getElementById("catalog-availability").onchange = e=>{ ui.catalogFilters.availability = e.target.value; renderView(); };
}
function renderCatalogListOnly(){
  // lightweight re-render preserving focus in search input
  const f = ui.catalogFilters;
  let books = DB.books.filter(b=>{
    const q = f.q.toLowerCase();
    const matchQ = !q || b.title.toLowerCase().includes(q) || b.author.toLowerCase().includes(q) || b.isbn.includes(q);
    const matchCat = f.category==="All" || b.category===f.category;
    const matchAvail = f.availability==="All" || (f.availability==="Available" ? b.available>0 : b.available===0);
    return matchQ && matchCat && matchAvail;
  });
  const resultsCount = document.querySelectorAll(".content .sub")[1];
  if(resultsCount) resultsCount.textContent = `${books.length} result${books.length!==1?'s':''}`;
  const gridArea = document.querySelector(".book-grid")?.parentElement;
  const target = document.querySelector(".book-grid") || document.querySelector(".empty-state");
  if(target){
    const html = books.length ? `<div class="book-grid">${books.map(bookCardHtml).join("")}</div>` : `<div class="empty-state">${ICONS.search}<b>No books match your search</b><span>Try a different title, author or filter.</span></div>`;
    target.outerHTML = html;
  }
}

/* ---------------- BOOK DETAIL MODAL ---------------- */
function openBookDetail(bookId){
  const b = DB.books.find(x=>x.id===bookId);
  const u = session.user;
  const myBorrow = DB.borrows.find(x=>x.bookId===bookId && x.userId===u.id && x.status!=="returned");
  const myReservation = DB.reservations.find(x=>x.bookId===bookId && x.userId===u.id && (x.status==="pending"||x.status==="ready"));
  const queueLen = DB.reservations.filter(x=>x.bookId===bookId && x.status==="pending").length;

  let actionHtml = "";
  if(u.role === "admin"){
    actionHtml = `<button class="btn btn-outline" onclick="closeModal();openEditBook('${b.id}')">${ICONS.edit} Edit book</button>`;
  } else if(myBorrow){
    const isOver = new Date(myBorrow.dueDate) < new Date();
    actionHtml = `
      <button class="btn btn-outline" onclick="renewBook('${myBorrow.id}')">${ICONS.refresh} Renew</button>
      <button class="btn btn-primary" onclick="returnBook('${myBorrow.id}')">${ICONS.check} Return book</button>
    `;
  } else if(myReservation){
    actionHtml = `<button class="btn btn-outline" onclick="cancelReservation('${myReservation.id}')">${ICONS.x} Cancel reservation</button>`;
  } else if(b.available > 0){
    actionHtml = `<button class="btn btn-primary" onclick="borrowBook('${b.id}')">${ICONS.book} Borrow this book</button>`;
  } else {
    actionHtml = `<button class="btn btn-primary" onclick="reserveBook('${b.id}')">${ICONS.bookmark} Reserve (queue: ${queueLen})</button>`;
  }

  const body = `
    <div class="modal-head">
      <div></div>
      <button class="modal-close" onclick="closeModal()">${ICONS.x}</button>
    </div>
    <div class="modal-body">
      <div class="book-detail-top">
        <div class="book-detail-cover" style="background:${COVER_GRADIENTS[b.category]}"><div class="glyph">${b.title}</div></div>
        <div style="flex:1;">
          <span class="cat" style="color:var(--navy-500);font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;">${b.category}</span>
          <h2 style="font-size:20px;margin-top:4px;">${b.title}</h2>
          <div class="detail-row">by ${b.author}</div>
          <div class="detail-row" style="margin-top:10px;">
            <span class="avail-tag ${b.available>0?'yes':'no'}">${b.available>0? b.available+' of '+b.total+' available':'All copies checked out'}</span>
          </div>
          ${myBorrow ? `<div style="margin-top:12px;"><span class="stamp ${new Date(myBorrow.dueDate)<new Date()?'overdue':'due'}">${new Date(myBorrow.dueDate)<new Date()?'OVERDUE — WAS DUE':'DUE'} ${fmtDate(myBorrow.dueDate)}</span></div>` : ""}
        </div>
      </div>
      <p style="font-size:13.5px;color:var(--ink-soft);line-height:1.65;margin-top:18px;">${b.description}</p>
      <div class="detail-grid">
        <div><div class="k">ISBN</div><div class="v mono">${b.isbn}</div></div>
        <div><div class="k">Location</div><div class="v">Rack ${b.rack}, Shelf ${b.shelf}</div></div>
        <div><div class="k">Total copies</div><div class="v">${b.total}</div></div>
        <div><div class="k">Available</div><div class="v">${b.available}</div></div>
      </div>
    </div>
    <div class="modal-foot">${actionHtml}</div>
  `;
  showModal(body, false);
}

/* ---------------- BORROW / RETURN / RENEW / RESERVE ---------------- */
function borrowBook(bookId){
  const b = DB.books.find(x=>x.id===bookId);
  const u = session.user;
  if(b.available <= 0){ toast("This book is no longer available.", "error"); return; }
  const already = DB.borrows.some(x=>x.bookId===bookId && x.userId===u.id && x.status!=="returned");
  if(already){ toast("You already have this book borrowed.", "error"); return; }

  b.available -= 1;
  const dueDate = addDaysISO(14);
  const rec = { id: uid("br"), userId:u.id, bookId, borrowDate:new Date().toISOString(), dueDate, status:"active", renewals:0 };
  DB.borrows.push(rec);
  addNotification(u.id, "borrow", "Book borrowed", `“${b.title}” is due on ${fmtDate(dueDate)}.`);
  toast(`Borrowed “${b.title}” — due ${fmtDate(dueDate)}`, "success");
  closeModal();
  renderView();
}

function returnBook(borrowId){
  const rec = DB.borrows.find(x=>x.id===borrowId);
  if(!rec) return;
  rec.status = "returned";
  rec.returnDate = new Date().toISOString();
  const b = DB.books.find(x=>x.id===rec.bookId);
  b.available += 1;
  addNotification(rec.userId, "return", "Book returned", `You returned “${b.title}”. Thanks!`);

  // notify next in reservation queue
  const nextRes = DB.reservations.filter(r=>r.bookId===b.id && r.status==="pending").sort((a,c)=>new Date(a.date)-new Date(c.date))[0];
  if(nextRes){
    nextRes.status = "ready";
    addNotification(nextRes.userId, "reserve", "Reserved book ready", `“${b.title}” is now available for pickup — held for 48 hours.`);
  }
  toast(`Returned “${b.title}”`, "success");
  closeModal();
  renderView();
}

function renewBook(borrowId){
  const rec = DB.borrows.find(x=>x.id===borrowId);
  if(!rec) return;
  const b = DB.books.find(x=>x.id===rec.bookId);
  const hasQueue = DB.reservations.some(r=>r.bookId===rec.bookId && r.status==="pending");
  if(rec.renewals >= 2){ toast("Renewal limit reached (2 renewals max).", "error"); return; }
  if(hasQueue){ toast("Can't renew — another student is waiting for this title.", "error"); return; }
  rec.dueDate = addDaysISO(daysBetween(new Date(), rec.dueDate) + 7 > 0 ? 7 : 7);
  rec.dueDate = addDaysISO(7);
  rec.renewals += 1;
  addNotification(rec.userId, "renew", "Book renewed", `“${b.title}” renewed — new due date ${fmtDate(rec.dueDate)}.`);
  toast(`Renewed — new due date ${fmtDate(rec.dueDate)}`, "success");
  closeModal();
  renderView();
}

function reserveBook(bookId){
  const b = DB.books.find(x=>x.id===bookId);
  const u = session.user;
  const already = DB.reservations.some(x=>x.bookId===bookId && x.userId===u.id && (x.status==="pending"||x.status==="ready"));
  if(already){ toast("You've already reserved this book.", "error"); return; }
  const queuePos = DB.reservations.filter(r=>r.bookId===bookId && r.status==="pending").length + 1;
  DB.reservations.push({ id: uid("rs"), userId:u.id, bookId, date:new Date().toISOString(), status:"pending", queuePos });
  addNotification(u.id, "reserve", "Reservation placed", `You're #${queuePos} in line for “${b.title}”.`);
  toast(`Reserved — you're #${queuePos} in the queue`, "success");
  closeModal();
  renderView();
}

function cancelReservation(resId){
  const r = DB.reservations.find(x=>x.id===resId);
  if(!r) return;
  r.status = "cancelled";
  toast("Reservation cancelled", "success");
  closeModal();
  renderView();
}

function addNotification(userId, type, title, msg){
  DB.notifications.unshift({ id: uid("n"), userId, type, title, msg, date:new Date().toISOString(), read:false });
}

/* ---------------- MY LIBRARY ---------------- */
function renderMyLibrary(){
  const u = session.user;
  const borrowed = DB.borrows.filter(b=>b.userId===u.id && b.status!=="returned");
  const reserved = DB.reservations.filter(r=>r.userId===u.id && (r.status==="pending"||r.status==="ready"));
  const history = DB.borrows.filter(b=>b.userId===u.id && b.status==="returned").sort((a,b)=>new Date(b.returnDate)-new Date(a.returnDate));

  const tabs = [["borrowed","Borrowed ("+borrowed.length+")"],["reserved","Reserved ("+reserved.length+")"],["history","History ("+history.length+")"]];

  let listHtml = "";
  if(ui.myLibraryTab === "borrowed"){
    listHtml = borrowed.length ? borrowed.map(b=>{
      const book = DB.books.find(x=>x.id===b.bookId);
      const isOver = new Date(b.dueDate) < new Date();
      return `<div class="card pad" style="display:flex;gap:16px;align-items:center;margin-bottom:12px;">
        <div class="mini-cover" style="width:52px;height:70px;background:${COVER_GRADIENTS[book.category]}"><span class="g">${book.glyph}</span></div>
        <div style="flex:1;min-width:0;">
          <b style="font-size:14.5px;display:block;cursor:pointer;" onclick="openBookDetail('${book.id}')">${book.title}</b>
          <span style="font-size:12.5px;color:var(--ink-soft);">${book.author} · Borrowed ${fmtDateShort(b.borrowDate)}</span>
          <div style="margin-top:8px;"><span class="stamp ${isOver?'overdue':'due'}">${isOver?'OVERDUE — WAS DUE':'DUE'} ${fmtDate(b.dueDate)}</span>${b.renewals>0?`<span style="font-size:11.5px;color:var(--ink-soft);margin-left:10px;">Renewed ${b.renewals}x</span>`:""}</div>
        </div>
        <div style="display:flex;gap:8px;flex-direction:column;">
          <button class="btn btn-outline btn-sm" onclick="renewBook('${b.id}')">Renew</button>
          <button class="btn btn-primary btn-sm" onclick="returnBook('${b.id}')">Return</button>
        </div>
      </div>`;
    }).join("") : emptyStateHtml(ICONS.book,"Nothing borrowed yet","Books you borrow will show up here.");
  } else if(ui.myLibraryTab === "reserved"){
    listHtml = reserved.length ? reserved.map(r=>{
      const book = DB.books.find(x=>x.id===r.bookId);
      return `<div class="card pad" style="display:flex;gap:16px;align-items:center;margin-bottom:12px;">
        <div class="mini-cover" style="width:52px;height:70px;background:${COVER_GRADIENTS[book.category]}"><span class="g">${book.glyph}</span></div>
        <div style="flex:1;min-width:0;">
          <b style="font-size:14.5px;display:block;cursor:pointer;" onclick="openBookDetail('${book.id}')">${book.title}</b>
          <span style="font-size:12.5px;color:var(--ink-soft);">${book.author} · Reserved ${fmtDateShort(r.date)}</span>
          <div style="margin-top:8px;"><span class="status-tag ${r.status}">${r.status==='ready'?'Ready for pickup':'Queue position '+ (r.queuePos||1)}</span></div>
        </div>
        <button class="btn btn-outline btn-sm" onclick="cancelReservation('${r.id}')">Cancel</button>
      </div>`;
    }).join("") : emptyStateHtml(ICONS.bookmark,"No reservations","Reserve a checked-out book to hold your place in line.");
  } else {
    listHtml = history.length ? `<div class="card" style="padding:6px 20px;">${history.map(b=>{
      const book = DB.books.find(x=>x.id===b.bookId);
      return `<div class="list-row"><div class="mini-cover" style="background:${COVER_GRADIENTS[book.category]}"><span class="g">${book.glyph}</span></div>
        <div style="flex:1;min-width:0;"><b style="font-size:13.5px;">${book.title}</b><br><span style="font-size:12px;color:var(--ink-soft);">${book.author}</span></div>
        <span style="font-size:12px;color:var(--ink-soft);">Returned ${fmtDateShort(b.returnDate)}</span>
      </div>`;
    }).join("")}</div>` : emptyStateHtml(ICONS.clock,"No history yet","Books you've returned will appear here.");
  }

  return `
    <div class="page-head"><div><h1>My Library</h1><p class="sub">Manage everything you've borrowed and reserved</p></div></div>
    <div class="tabs">${tabs.map(([k,l])=>`<button class="tab-btn ${ui.myLibraryTab===k?'active':''}" onclick="setMyLibraryTab('${k}')">${l}</button>`).join("")}</div>
    <div>${listHtml}</div>
  `;
}
function setMyLibraryTab(t){ ui.myLibraryTab = t; renderView(); }
function emptyStateHtml(icon,title,sub){
  return `<div class="card empty-state">${icon}<b>${title}</b><span style="font-size:12.5px;">${sub}</span></div>`;
}

/* ---------------- SEAT MAP ---------------- */
function renderSeatMap(){
  const u = session.user;
  const zones = [...new Set(DB.seats.map(s=>s.zone))];
  const totalAvail = DB.seats.filter(s=>!s.occupied).length;

  return `
    <div class="page-head"><div><h1>Seat Map</h1><p class="sub">${totalAvail} of ${DB.seats.length} seats available right now</p></div></div>
    <div class="seat-legend">
      <div class="it"><span class="sw" style="background:var(--green-bg);border:1px solid #c7e8d8;"></span>Available</div>
      <div class="it"><span class="sw" style="background:var(--bg-alt);"></span>Occupied</div>
      <div class="it"><span class="sw" style="background:var(--navy-700);"></span>Your reservation</div>
    </div>
    ${zones.map(z=>{
      const seatsInZone = DB.seats.filter(s=>s.zone===z);
      const availInZone = seatsInZone.filter(s=>!s.occupied).length;
      return `<div class="zone-block">
        <div class="zone-title"><h3>${z}</h3><span>${availInZone}/${seatsInZone.length} available</span></div>
        <div class="seat-grid">${seatsInZone.map(s=>{
          const mine = s.reservedBy === u.id;
          const cls = mine ? "mine" : s.occupied ? "occupied" : "available";
          return `<div class="seat ${cls}" title="${s.id}" onclick="${!s.occupied || mine ? `handleSeatClick('${s.id}')` : ''}">${s.id.split('-')[1]}</div>`;
        }).join("")}</div>
      </div>`;
    }).join("")}
  `;
}
function handleSeatClick(seatId){
  const seat = DB.seats.find(s=>s.id===seatId);
  const u = session.user;
  if(seat.reservedBy === u.id){
    // release
    const body = `
      <div class="modal-head"><h3 style="font-size:17px;">Release seat ${seat.id}</h3><button class="modal-close" onclick="closeModal()">${ICONS.x}</button></div>
      <div class="modal-body"><p style="font-size:13.5px;color:var(--ink-soft);">This seat in <b style="color:var(--ink);">${seat.zone}</b> is currently reserved under your name. Release it to make it available for other students?</p></div>
      <div class="modal-foot"><button class="btn btn-outline" onclick="closeModal()">Keep it</button><button class="btn btn-danger" onclick="releaseSeat('${seat.id}')">Release seat</button></div>
    `;
    showModal(body,false);
    return;
  }
  const alreadyHas = DB.seats.some(s=>s.reservedBy===u.id);
  const body = `
    <div class="modal-head"><h3 style="font-size:17px;">Reserve seat ${seat.id}</h3><button class="modal-close" onclick="closeModal()">${ICONS.x}</button></div>
    <div class="modal-body">
      <div class="detail-grid">
        <div><div class="k">Zone</div><div class="v">${seat.zone}</div></div>
        <div><div class="k">Seat</div><div class="v mono">${seat.id}</div></div>
        <div><div class="k">Valid for</div><div class="v">Today, until closing</div></div>
        <div><div class="k">Status</div><div class="v" style="color:var(--green);">Available</div></div>
      </div>
      ${alreadyHas ? `<div class="form-error show" style="margin-top:16px;">You already hold a reserved seat today. Reserving this one will release your current seat.</div>` : ""}
    </div>
    <div class="modal-foot"><button class="btn btn-outline" onclick="closeModal()">Cancel</button><button class="btn btn-primary" onclick="confirmSeatReserve('${seat.id}')">Confirm reservation</button></div>
  `;
  showModal(body,false);
}
function confirmSeatReserve(seatId){
  const u = session.user;
  // release any other seat the user holds
  DB.seats.forEach(s=>{ if(s.reservedBy===u.id) { s.reservedBy=null; s.occupied=false; } });
  const seat = DB.seats.find(s=>s.id===seatId);
  seat.occupied = true;
  seat.reservedBy = u.id;
  DB.seatReservations.push({ id: uid("sr"), userId:u.id, seatId, date:new Date().toISOString() });
  addNotification(u.id, "seat", "Seat reserved", `Seat ${seat.id} in ${seat.zone} is reserved for you today.`);
  toast(`Seat ${seat.id} reserved`, "success");
  closeModal();
  renderView();
}
function releaseSeat(seatId){
  const seat = DB.seats.find(s=>s.id===seatId);
  seat.occupied = false;
  seat.reservedBy = null;
  toast(`Seat ${seat.id} released`, "success");
  closeModal();
  renderView();
}

/* ---------------- LIBRARY OVERVIEW ---------------- */
function renderOverview(){
  const facilities = [
    {ic:ICONS.wifi, t:"Free High-Speed Wi-Fi", d:"Campus-wide access across all four floors, no login required for enrolled students."},
    {ic:ICONS.print, t:"Print & Scan Stations", d:"Self-service printing on Level 1 — 30 free pages/month per student."},
    {ic:ICONS.coffee, t:"Reading Café", d:"Coffee and light snacks permitted in the ground-floor lounge only."},
    {ic:ICONS.seat, t:"96 Study Seats", d:"Reading Hall, Silent Zone, Group Pods and a 20-seat Computer Lab."},
    {ic:ICONS.book, t:"Interlibrary Loan", d:"Request titles from partner campuses — typically arrives in 3–5 days."},
    {ic:ICONS.users, t:"Research Help Desk", d:"Librarians available Mon–Fri, 10 AM–6 PM for citation and research support."},
  ];
  const rules = [
    "Borrowed books are due 14 days from checkout, with up to 2 renewals if no one else has reserved the title.",
    "Silent Study Zone is strictly no-talking — take calls and discussions to the Group Pods or lobby.",
    "Reserved seats are held for 30 minutes past your check-in time before being released.",
    "Food is allowed only in the ground-floor Reading Café; drinks with lids are fine elsewhere.",
    "Lost or damaged books are billed at replacement cost plus a $10 processing fee.",
    "ID cards must be presented to borrow, renew or collect a reserved item at the front desk.",
  ];
  const timings = [["Monday – Friday","6:30 AM – 11:00 PM"],["Saturday","8:00 AM – 9:00 PM"],["Sunday","10:00 AM – 8:00 PM"],["Public holidays","10:00 AM – 5:00 PM"],["Exam period (extended)","24 hours"]];

  return `
    <div class="page-head"><div><h1>Library Overview</h1><p class="sub">Facilities, rules, timings and how to reach us</p></div></div>
    <div class="two-col">
      <div>
        <div class="card pad" style="margin-bottom:20px;">
          <h3 style="font-size:16px;margin-bottom:8px;">Facilities</h3>
          <div class="info-grid">${facilities.map(f=>`<div class="facility-item"><div class="ic">${f.ic}</div><div><b>${f.t}</b><span>${f.d}</span></div></div>`).join("")}</div>
        </div>
        <div class="card pad">
          <h3 style="font-size:16px;margin-bottom:6px;">Library Rules</h3>
          ${rules.map((r,i)=>`<div class="rule-item"><div class="n">${i+1}</div><span>${r}</span></div>`).join("")}
        </div>
      </div>
      <div>
        <div class="card pad" style="margin-bottom:20px;">
          <h3 style="font-size:16px;margin-bottom:10px;">Opening Hours</h3>
          ${timings.map(([d,t])=>`<div class="timing-row"><span>${d}</span><b>${t}</b></div>`).join("")}
        </div>
        <div class="card pad">
          <h3 style="font-size:16px;margin-bottom:12px;">Contact</h3>
          <div class="rule-item" style="border:none;padding:6px 0;">${ICONS.mappin}&nbsp; Ashcombe College, Library Building, 2nd Floor</div>
          <div class="rule-item" style="border:none;padding:6px 0;">${ICONS.phone}&nbsp; (555) 213-4890</div>
          <div class="rule-item" style="border:none;padding:6px 0;">${ICONS.mail}&nbsp; library@ashcombe.edu</div>
        </div>
      </div>
    </div>
  `;
}

/* ---------------- PROFILE ---------------- */
function renderProfile(){
  const u = session.user;
  const myBorrows = DB.borrows.filter(b=>b.userId===u.id);
  const activeCount = myBorrows.filter(b=>b.status!=="returned").length;
  const historyCount = myBorrows.filter(b=>b.status==="returned").length;

  return `
    <div class="page-head"><div><h1>Profile</h1><p class="sub">Your account details</p></div></div>
    <div class="two-col">
      <div class="card pad">
        <div style="display:flex;align-items:center;gap:16px;margin-bottom:20px;">
          <div class="avatar" style="width:64px;height:64px;font-size:22px;">${initials(u.name)}</div>
          <div><h3 style="font-size:19px;">${u.name}</h3><span class="tag-role ${u.role}" style="margin-top:4px;display:inline-block;">${u.role==='admin'?'Admin / Librarian':'Student'}</span></div>
        </div>
        <div class="detail-grid" style="grid-template-columns:1fr 1fr;">
          <div><div class="k">Email</div><div class="v" style="font-weight:500;">${u.email}</div></div>
          <div><div class="k">${u.role==='admin'?'Staff ID':'Student ID'}</div><div class="v mono">${u.idval}</div></div>
          <div><div class="k">Department</div><div class="v" style="font-weight:500;">${u.dept}</div></div>
          <div><div class="k">Member since</div><div class="v" style="font-weight:500;">${fmtDate(u.joined)}</div></div>
        </div>
        <button class="btn btn-outline" style="margin-top:22px;" onclick="openEditProfile()">${ICONS.edit} Edit profile</button>
      </div>
      <div class="card pad">
        <h3 style="font-size:16px;margin-bottom:14px;">Reading activity</h3>
        <div class="timing-row"><span>Currently borrowed</span><b>${activeCount}</b></div>
        <div class="timing-row"><span>Total books read</span><b>${historyCount}</b></div>
        <div class="timing-row"><span>Active reservations</span><b>${DB.reservations.filter(r=>r.userId===u.id && (r.status==='pending'||r.status==='ready')).length}</b></div>
        <div class="timing-row"><span>Seat reservation</span><b>${DB.seats.find(s=>s.reservedBy===u.id)?.id || "None"}</b></div>
      </div>
    </div>
  `;
}
function openEditProfile(){
  const u = session.user;
  const body = `
    <div class="modal-head"><h3 style="font-size:17px;">Edit profile</h3><button class="modal-close" onclick="closeModal()">${ICONS.x}</button></div>
    <div class="modal-body">
      <div class="field"><label>Full name</label><input id="ep-name" value="${u.name}"></div>
      <div class="field"><label>Department</label><input id="ep-dept" value="${u.dept}"></div>
      <div class="field"><label>Email</label><input id="ep-email" value="${u.email}"></div>
    </div>
    <div class="modal-foot"><button class="btn btn-outline" onclick="closeModal()">Cancel</button><button class="btn btn-primary" onclick="saveProfile()">Save changes</button></div>
  `;
  showModal(body,false);
}
function saveProfile(){
  const u = session.user;
  const name = document.getElementById("ep-name").value.trim();
  const dept = document.getElementById("ep-dept").value.trim();
  const email = document.getElementById("ep-email").value.trim();
  if(!name || !dept || !email){ toast("Please fill in all fields.", "error"); return; }
  u.name = name; u.dept = dept; u.email = email;
  renderTopbarUser();
  toast("Profile updated", "success");
  closeModal();
  renderView();
}

/* ---------------- NOTIFICATIONS ---------------- */
function refreshNotifBadge(){
  const unread = DB.notifications.filter(n=>n.userId===session.user.id && !n.read).length;
  document.getElementById("notif-dot").style.display = unread ? "block" : "none";
}
function toggleNotifPanel(){
  ui.notifOpen = !ui.notifOpen;
  const panel = document.getElementById("notif-panel");
  if(ui.notifOpen){
    const mine = DB.notifications.filter(n=>n.userId===session.user.id).sort((a,b)=>new Date(b.date)-new Date(a.date));
    panel.innerHTML = `
      <div class="notif-head"><b style="font-size:14px;">Notifications</b>${mine.length ? `<button class="btn btn-ghost btn-sm" onclick="markAllRead()">Mark all read</button>` : ""}</div>
      ${mine.length ? mine.map(n=>notifItemHtml(n)).join("") : `<div class="empty-state" style="padding:36px 16px;">${ICONS.alert}<b>No notifications</b><span style="font-size:12px;">You're all caught up.</span></div>`}
    `;
    mine.forEach(n=>n.read=true);
    panel.classList.add("show");
  } else {
    panel.classList.remove("show");
  }
  refreshNotifBadge();
}
function notifItemHtml(n){
  const icMap = {borrow:ICONS.book, return:ICONS.check, renew:ICONS.refresh, reserve:ICONS.bookmark, seat:ICONS.seat, due:ICONS.clock, info:ICONS.info};
  const colMap = {borrow:["var(--navy-100)","var(--navy-700)"], return:["var(--green-bg)","var(--green)"], renew:["var(--navy-100)","var(--navy-700)"], reserve:["var(--amber-bg)","var(--amber)"], seat:["var(--navy-100)","var(--navy-700)"], due:["var(--red-bg)","var(--red)"], info:["var(--bg-alt)","var(--ink-soft)"]};
  const [bg,col] = colMap[n.type]||colMap.info;
  return `<div class="notif-item ${!n.read?'unread':''}">
    <div class="notif-ic" style="background:${bg};color:${col};">${icMap[n.type]||ICONS.info}</div>
    <div><b>${n.title}</b><p>${n.msg}</p><span class="t">${fmtDateShort(n.date)}</span></div>
  </div>`;
}
function markAllRead(){
  DB.notifications.forEach(n=>{ if(n.userId===session.user.id) n.read=true; });
  toggleNotifPanel(); toggleNotifPanel();
}
document.addEventListener("click", (e)=>{
  const panel = document.getElementById("notif-panel");
  const bell = document.getElementById("notif-bell");
  if(ui.notifOpen && panel && !panel.contains(e.target) && e.target !== bell && !bell.contains(e.target)){
    ui.notifOpen = false;
    panel.classList.remove("show");
  }
});

/* ---------------- MODAL HELPERS ---------------- */
function showModal(innerHtml, wide){
  const box = document.getElementById("modal-box");
  box.className = "modal" + (wide ? " wide" : "");
  box.innerHTML = innerHtml;
  document.getElementById("modal-overlay").classList.add("show");
}
function closeModal(){
  document.getElementById("modal-overlay").classList.remove("show");
}
document.getElementById("modal-overlay").addEventListener("click", (e)=>{
  if(e.target.id === "modal-overlay") closeModal();
});

/* ================================================================
   ADMIN DASHBOARD
   ================================================================ */
function renderAdmin(){
  const tabs = [["overview","Overview"],["books","Books"],["users","Users"],["borrowing","Borrowing"],["reservations","Reservations"],["seats","Seats"]];
  let body = "";
  if(ui.adminTab==="overview") body = renderAdminOverview();
  else if(ui.adminTab==="books") body = renderAdminBooks();
  else if(ui.adminTab==="users") body = renderAdminUsers();
  else if(ui.adminTab==="borrowing") body = renderAdminBorrowing();
  else if(ui.adminTab==="reservations") body = renderAdminReservations();
  else if(ui.adminTab==="seats") body = renderAdminSeats();

  return `
    <div class="page-head"><div><h1>Admin Dashboard</h1><p class="sub">Manage the collection, members and activity</p></div></div>
    <div class="admin-tabs">${tabs.map(([k,l])=>`<div class="admin-tab ${ui.adminTab===k?'active':''}" onclick="setAdminTab('${k}')">${l}</div>`).join("")}</div>
    ${body}
  `;
}
function setAdminTab(t){ ui.adminTab = t; renderView(); }

function renderAdminOverview(){
  const totalBooks = DB.books.reduce((s,b)=>s+b.total,0);
  const availBooks = DB.books.reduce((s,b)=>s+b.available,0);
  const totalUsers = DB.users.filter(u=>u.role==="student").length;
  const activeBorrows = DB.borrows.filter(b=>b.status!=="returned").length;
  const overdue = DB.borrows.filter(b=>b.status!=="returned" && new Date(b.dueDate)<new Date()).length;
  const pendingRes = DB.reservations.filter(r=>r.status==="pending"||r.status==="ready").length;
  const occSeats = DB.seats.filter(s=>s.occupied).length;

  const recentBorrows = [...DB.borrows].sort((a,b)=>new Date(b.borrowDate)-new Date(a.borrowDate)).slice(0,6);

  return `
    <div class="stat-grid">
      <div class="card stat-card"><div class="stat-icon" style="background:var(--navy-100);color:var(--navy-700);">${ICONS.book}</div><b>${totalBooks}</b><span>Total copies</span></div>
      <div class="card stat-card"><div class="stat-icon" style="background:var(--green-bg);color:var(--green);">${ICONS.check}</div><b>${availBooks}</b><span>Available copies</span></div>
      <div class="card stat-card"><div class="stat-icon" style="background:var(--navy-100);color:var(--navy-700);">${ICONS.users}</div><b>${totalUsers}</b><span>Registered students</span></div>
      <div class="card stat-card"><div class="stat-icon" style="background:${overdue?'var(--red-bg)':'var(--navy-100)'};color:${overdue?'var(--red)':'var(--navy-700)'};">${ICONS.clock}</div><b>${activeBorrows}</b><span>${overdue} overdue</span></div>
    </div>
    <div class="stat-grid">
      <div class="card stat-card"><div class="stat-icon" style="background:var(--amber-bg);color:var(--amber);">${ICONS.bookmark}</div><b>${pendingRes}</b><span>Book reservations</span></div>
      <div class="card stat-card"><div class="stat-icon" style="background:var(--navy-100);color:var(--navy-700);">${ICONS.seat}</div><b>${occSeats}/${DB.seats.length}</b><span>Seats occupied</span></div>
      <div class="card stat-card"><div class="stat-icon" style="background:var(--navy-100);color:var(--navy-700);">${ICONS.library}</div><b>${CATEGORIES.length}</b><span>Categories</span></div>
      <div class="card stat-card"><div class="stat-icon" style="background:var(--green-bg);color:var(--green);">${ICONS.dashboard}</div><b>${isLibraryOpen()?'Open':'Closed'}</b><span>Current status</span></div>
    </div>
    <div class="card pad" style="margin-top:6px;">
      <h3 style="font-size:16px;margin-bottom:12px;">Recent borrowing activity</h3>
      ${recentBorrows.length ? recentBorrows.map(b=>{
        const book = DB.books.find(x=>x.id===b.bookId); const user = DB.users.find(x=>x.id===b.userId);
        return `<div class="list-row"><div class="avatar" style="width:32px;height:32px;font-size:11px;">${initials(user?.name||'?')}</div>
          <div style="flex:1;"><b style="font-size:13px;">${user?.name}</b> <span style="font-size:12.5px;color:var(--ink-soft);">borrowed ${book?.title}</span></div>
          <span style="font-size:12px;color:var(--ink-soft);">${fmtDateShort(b.borrowDate)}</span></div>`;
      }).join("") : emptyStateHtml(ICONS.clock,"No activity yet","Borrowing activity will appear here.")}
    </div>
  `;
}

/* ---- Admin: Books ---- */
function renderAdminBooks(){
  return `
    <div style="display:flex;justify-content:flex-end;margin-bottom:14px;"><button class="btn btn-primary btn-sm" onclick="openAddBook()">${ICONS.plus} Add book</button></div>
    <div class="card table-wrap">
      <table>
        <thead><tr><th>Title</th><th>Author</th><th>Category</th><th>ISBN</th><th>Copies</th><th>Available</th><th></th></tr></thead>
        <tbody>
        ${DB.books.map(b=>`<tr>
          <td><b style="font-size:13px;">${b.title}</b></td>
          <td>${b.author}</td>
          <td>${b.category}</td>
          <td class="mono" style="font-size:12px;">${b.isbn}</td>
          <td>${b.total}</td>
          <td><span class="avail-tag ${b.available>0?'yes':'no'}">${b.available}</span></td>
          <td><div class="row-actions">
            <button class="icon-btn-sm" onclick="openEditBook('${b.id}')">${ICONS.edit}</button>
            <button class="icon-btn-sm" onclick="deleteBook('${b.id}')" style="color:var(--red);">${ICONS.trash}</button>
          </div></td>
        </tr>`).join("")}
        </tbody>
      </table>
    </div>
  `;
}
function bookFormHtml(b){
  b = b || {title:"",author:"",category:CATEGORIES[0],isbn:"",description:"",rack:"R-3",shelf:"A",total:1,available:1,glyph:"BK"};
  return `
    <div class="form-grid">
      <div class="field"><label>Title</label><input id="bf-title" value="${b.title}"></div>
      <div class="field"><label>Author</label><input id="bf-author" value="${b.author}"></div>
      <div class="field"><label>Category</label><select id="bf-category">${CATEGORIES.map(c=>`<option ${b.category===c?'selected':''}>${c}</option>`).join("")}</select></div>
      <div class="field"><label>ISBN</label><input id="bf-isbn" value="${b.isbn}"></div>
      <div class="field"><label>Rack</label><input id="bf-rack" value="${b.rack}"></div>
      <div class="field"><label>Shelf</label><input id="bf-shelf" value="${b.shelf}"></div>
      <div class="field"><label>Total copies</label><input id="bf-total" type="number" min="0" value="${b.total}"></div>
      <div class="field"><label>Available copies</label><input id="bf-available" type="number" min="0" value="${b.available}"></div>
    </div>
    <div class="field"><label>Description</label><textarea id="bf-description" rows="3" style="width:100%;padding:11px 13px;border:1px solid var(--line-strong);border-radius:10px;font-size:14px;resize:vertical;">${b.description}</textarea></div>
  `;
}
function openAddBook(){
  const body = `
    <div class="modal-head"><h3 style="font-size:17px;">Add a book</h3><button class="modal-close" onclick="closeModal()">${ICONS.x}</button></div>
    <div class="modal-body">${bookFormHtml()}</div>
    <div class="modal-foot"><button class="btn btn-outline" onclick="closeModal()">Cancel</button><button class="btn btn-primary" onclick="saveNewBook()">Add book</button></div>
  `;
  showModal(body,true);
}
function readBookForm(){
  return {
    title: document.getElementById("bf-title").value.trim(),
    author: document.getElementById("bf-author").value.trim(),
    category: document.getElementById("bf-category").value,
    isbn: document.getElementById("bf-isbn").value.trim(),
    rack: document.getElementById("bf-rack").value.trim(),
    shelf: document.getElementById("bf-shelf").value.trim(),
    total: parseInt(document.getElementById("bf-total").value)||0,
    available: parseInt(document.getElementById("bf-available").value)||0,
    description: document.getElementById("bf-description").value.trim(),
  };
}
function saveNewBook(){
  const f = readBookForm();
  if(!f.title || !f.author || !f.isbn){ toast("Title, author and ISBN are required.", "error"); return; }
  if(f.available > f.total){ toast("Available copies can't exceed total copies.", "error"); return; }
  const glyph = f.category.slice(0,2).toUpperCase();
  DB.books.push({ id: uid("b"), glyph, ...f });
  toast(`“${f.title}” added to the catalog`, "success");
  closeModal();
  renderView();
}
function openEditBook(bookId){
  const b = DB.books.find(x=>x.id===bookId);
  const body = `
    <div class="modal-head"><h3 style="font-size:17px;">Edit book</h3><button class="modal-close" onclick="closeModal()">${ICONS.x}</button></div>
    <div class="modal-body">${bookFormHtml(b)}</div>
    <div class="modal-foot"><button class="btn btn-outline" onclick="closeModal()">Cancel</button><button class="btn btn-primary" onclick="saveEditBook('${bookId}')">Save changes</button></div>
  `;
  showModal(body,true);
}
function saveEditBook(bookId){
  const b = DB.books.find(x=>x.id===bookId);
  const f = readBookForm();
  if(!f.title || !f.author || !f.isbn){ toast("Title, author and ISBN are required.", "error"); return; }
  if(f.available > f.total){ toast("Available copies can't exceed total copies.", "error"); return; }
  Object.assign(b, f);
  toast("Book updated", "success");
  closeModal();
  renderView();
}
function deleteBook(bookId){
  const b = DB.books.find(x=>x.id===bookId);
  const body = `
    <div class="modal-head"><h3 style="font-size:17px;">Delete book</h3><button class="modal-close" onclick="closeModal()">${ICONS.x}</button></div>
    <div class="modal-body"><p style="font-size:13.5px;color:var(--ink-soft);">Remove <b style="color:var(--ink);">“${b.title}”</b> from the catalog? This can't be undone.</p></div>
    <div class="modal-foot"><button class="btn btn-outline" onclick="closeModal()">Cancel</button><button class="btn btn-danger" onclick="confirmDeleteBook('${bookId}')">Delete</button></div>
  `;
  showModal(body,false);
}
function confirmDeleteBook(bookId){
  DB.books = DB.books.filter(x=>x.id!==bookId);
  DB.borrows = DB.borrows.filter(x=>x.bookId!==bookId);
  DB.reservations = DB.reservations.filter(x=>x.bookId!==bookId);
  toast("Book deleted", "success");
  closeModal();
  renderView();
}

/* ---- Admin: Users ---- */
function renderAdminUsers(){
  return `
    <div style="display:flex;justify-content:flex-end;margin-bottom:14px;"><button class="btn btn-primary btn-sm" onclick="openAddUser()">${ICONS.plus} Add user</button></div>
    <div class="card table-wrap">
      <table>
        <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Department</th><th>ID</th><th>Active borrows</th><th></th></tr></thead>
        <tbody>
        ${DB.users.map(u=>{
          const active = DB.borrows.filter(b=>b.userId===u.id && b.status!=="returned").length;
          return `<tr>
          <td style="display:flex;align-items:center;gap:9px;"><div class="avatar" style="width:28px;height:28px;font-size:10.5px;">${initials(u.name)}</div>${u.name}</td>
          <td>${u.email}</td>
          <td><span class="tag-role ${u.role}">${u.role}</span></td>
          <td>${u.dept}</td>
          <td class="mono" style="font-size:12px;">${u.idval}</td>
          <td>${active}</td>
          <td><div class="row-actions">
            <button class="icon-btn-sm" onclick="openEditUser('${u.id}')">${ICONS.edit}</button>
            <button class="icon-btn-sm" onclick="deleteUser('${u.id}')" style="color:var(--red);">${ICONS.trash}</button>
          </div></td>
        </tr>`}).join("")}
        </tbody>
      </table>
    </div>
  `;
}
function userFormHtml(u){
  u = u || {name:"",email:"",role:"student",dept:"",idval:"",password:""};
  return `
    <div class="form-grid">
      <div class="field"><label>Full name</label><input id="uf-name" value="${u.name}"></div>
      <div class="field"><label>Email</label><input id="uf-email" value="${u.email}"></div>
      <div class="field"><label>Role</label><select id="uf-role"><option value="student" ${u.role==='student'?'selected':''}>Student</option><option value="admin" ${u.role==='admin'?'selected':''}>Admin</option></select></div>
      <div class="field"><label>Department</label><input id="uf-dept" value="${u.dept}"></div>
      <div class="field"><label>ID</label><input id="uf-idval" value="${u.idval}"></div>
      <div class="field"><label>Password ${u.id?'(leave blank to keep)':''}</label><input id="uf-password" type="password" placeholder="${u.id?'••••••••':'Set a password'}"></div>
    </div>
  `;
}
function openAddUser(){
  const body = `
    <div class="modal-head"><h3 style="font-size:17px;">Add user</h3><button class="modal-close" onclick="closeModal()">${ICONS.x}</button></div>
    <div class="modal-body">${userFormHtml()}</div>
    <div class="modal-foot"><button class="btn btn-outline" onclick="closeModal()">Cancel</button><button class="btn btn-primary" onclick="saveNewUser()">Add user</button></div>
  `;
  showModal(body,true);
}
function saveNewUser(){
  const name = document.getElementById("uf-name").value.trim();
  const email = document.getElementById("uf-email").value.trim().toLowerCase();
  const role = document.getElementById("uf-role").value;
  const dept = document.getElementById("uf-dept").value.trim();
  const idval = document.getElementById("uf-idval").value.trim();
  const password = document.getElementById("uf-password").value || "welcome123";
  if(!name || !email || !dept || !idval){ toast("Please fill in all required fields.", "error"); return; }
  if(DB.users.some(u=>u.email.toLowerCase()===email)){ toast("A user with this email already exists.", "error"); return; }
  DB.users.push({ id: uid("u"), name, email, password, role, dept, idval, joined:new Date().toISOString() });
  toast("User added", "success");
  closeModal();
  renderView();
}
function openEditUser(userId){
  const u = DB.users.find(x=>x.id===userId);
  const body = `
    <div class="modal-head"><h3 style="font-size:17px;">Edit user</h3><button class="modal-close" onclick="closeModal()">${ICONS.x}</button></div>
    <div class="modal-body">${userFormHtml(u)}</div>
    <div class="modal-foot"><button class="btn btn-outline" onclick="closeModal()">Cancel</button><button class="btn btn-primary" onclick="saveEditUser('${userId}')">Save changes</button></div>
  `;
  showModal(body,true);
}
function saveEditUser(userId){
  const u = DB.users.find(x=>x.id===userId);
  const name = document.getElementById("uf-name").value.trim();
  const email = document.getElementById("uf-email").value.trim().toLowerCase();
  const role = document.getElementById("uf-role").value;
  const dept = document.getElementById("uf-dept").value.trim();
  const idval = document.getElementById("uf-idval").value.trim();
  const password = document.getElementById("uf-password").value;
  if(!name || !email || !dept || !idval){ toast("Please fill in all required fields.", "error"); return; }
  Object.assign(u,{name,email,role,dept,idval});
  if(password) u.password = password;
  toast("User updated", "success");
  closeModal();
  renderView();
}
function deleteUser(userId){
  if(userId === session.user.id){ toast("You can't delete your own account while signed in.", "error"); return; }
  const u = DB.users.find(x=>x.id===userId);
  const body = `
    <div class="modal-head"><h3 style="font-size:17px;">Remove user</h3><button class="modal-close" onclick="closeModal()">${ICONS.x}</button></div>
    <div class="modal-body"><p style="font-size:13.5px;color:var(--ink-soft);">Remove <b style="color:var(--ink);">${u.name}</b> from Libora? Their borrowing history will be kept for records.</p></div>
    <div class="modal-foot"><button class="btn btn-outline" onclick="closeModal()">Cancel</button><button class="btn btn-danger" onclick="confirmDeleteUser('${userId}')">Remove</button></div>
  `;
  showModal(body,false);
}
function confirmDeleteUser(userId){
  DB.users = DB.users.filter(x=>x.id!==userId);
  toast("User removed", "success");
  closeModal();
  renderView();
}

/* ---- Admin: Borrowing ---- */
function renderAdminBorrowing(){
  const rows = [...DB.borrows].sort((a,b)=>new Date(b.borrowDate)-new Date(a.borrowDate));
  return `
    <div class="card table-wrap">
      <table>
        <thead><tr><th>Student</th><th>Book</th><th>Borrowed</th><th>Due</th><th>Status</th><th></th></tr></thead>
        <tbody>
        ${rows.length ? rows.map(b=>{
          const book = DB.books.find(x=>x.id===b.bookId); const user = DB.users.find(x=>x.id===b.userId);
          const isOver = b.status!=="returned" && new Date(b.dueDate) < new Date();
          const status = b.status==="returned" ? "returned" : isOver ? "overdue" : "active";
          return `<tr>
            <td>${user?.name||'—'}</td>
            <td>${book?.title||'—'}</td>
            <td>${fmtDateShort(b.borrowDate)}</td>
            <td class="mono" style="font-size:12px;">${fmtDateShort(b.dueDate)}</td>
            <td><span class="status-tag ${status}">${status}</span></td>
            <td>${status!=="returned" ? `<button class="btn btn-outline btn-sm" onclick="adminMarkReturned('${b.id}')">Mark returned</button>` : ""}</td>
          </tr>`;
        }).join("") : `<tr><td colspan="6"><div class="empty-state">${ICONS.clock}<b>No borrowing records yet</b></div></td></tr>`}
        </tbody>
      </table>
    </div>
  `;
}
function adminMarkReturned(borrowId){ returnBookAdmin(borrowId); }
function returnBookAdmin(borrowId){
  const rec = DB.borrows.find(x=>x.id===borrowId);
  rec.status="returned"; rec.returnDate=new Date().toISOString();
  const b = DB.books.find(x=>x.id===rec.bookId);
  b.available += 1;
  const nextRes = DB.reservations.filter(r=>r.bookId===b.id && r.status==="pending").sort((a,c)=>new Date(a.date)-new Date(c.date))[0];
  if(nextRes){ nextRes.status="ready"; addNotification(nextRes.userId, "reserve", "Reserved book ready", `“${b.title}” is now available for pickup.`); }
  toast("Marked as returned", "success");
  renderView();
}

/* ---- Admin: Reservations ---- */
function renderAdminReservations(){
  const rows = [...DB.reservations].sort((a,b)=>new Date(b.date)-new Date(a.date));
  return `
    <div class="card table-wrap">
      <table>
        <thead><tr><th>Student</th><th>Book</th><th>Reserved</th><th>Status</th><th></th></tr></thead>
        <tbody>
        ${rows.length ? rows.map(r=>{
          const book = DB.books.find(x=>x.id===r.bookId); const user = DB.users.find(x=>x.id===r.userId);
          return `<tr>
            <td>${user?.name||'—'}</td>
            <td>${book?.title||'—'}</td>
            <td>${fmtDateShort(r.date)}</td>
            <td><span class="status-tag ${r.status}">${r.status}</span></td>
            <td>${(r.status==="pending"||r.status==="ready") ? `<button class="btn btn-outline btn-sm" onclick="adminCancelReservation('${r.id}')">Cancel</button>` : ""}</td>
          </tr>`;
        }).join("") : `<tr><td colspan="5"><div class="empty-state">${ICONS.bookmark}<b>No reservations yet</b></div></td></tr>`}
        </tbody>
      </table>
    </div>
  `;
}
function adminCancelReservation(resId){
  const r = DB.reservations.find(x=>x.id===resId);
  r.status="cancelled";
  toast("Reservation cancelled", "success");
  renderView();
}

/* ---- Admin: Seats ---- */
function renderAdminSeats(){
  const zones = [...new Set(DB.seats.map(s=>s.zone))];
  return `
    <div class="card pad">
      ${zones.map(z=>{
        const seatsInZone = DB.seats.filter(s=>s.zone===z);
        return `<div class="zone-block">
          <div class="zone-title"><h3>${z}</h3><span>${seatsInZone.filter(s=>!s.occupied).length}/${seatsInZone.length} available</span></div>
          <div class="seat-grid">${seatsInZone.map(s=>{
            const cls = s.reservedBy ? "mine" : s.occupied ? "occupied" : "available";
            const who = s.reservedBy ? DB.users.find(u=>u.id===s.reservedBy)?.name : null;
            return `<div class="seat ${cls}" title="${s.id}${who?' — '+who:''}" onclick="adminToggleSeat('${s.id}')">${s.id.split('-')[1]}</div>`;
          }).join("")}</div>
        </div>`;
      }).join("")}
    </div>
  `;
}
function adminToggleSeat(seatId){
  const s = DB.seats.find(x=>x.id===seatId);
  if(s.occupied){ s.occupied=false; s.reservedBy=null; toast(`Seat ${s.id} freed`, "success"); }
  else { s.occupied=true; toast(`Seat ${s.id} marked occupied`, "success"); }
  renderView();
}

/* ================================================================
   AI LIBRARY ASSISTANT (rule-based, grounded in live library data)
   ================================================================ */
const AI_SUGGESTIONS = ["Is the library open now?","Find books on algorithms","Any seats available?","What are the borrowing rules?","Where's the Wi-Fi info?"];

function toggleAiPanel(){
  ui.aiOpen = !ui.aiOpen;
  const panel = document.getElementById("ai-panel");
  if(ui.aiOpen){
    panel.classList.add("show");
    if(ui.aiHistory.length===0){
      pushAiMessage("bot", `Hi ${session.user.name.split(' ')[0]}, I'm the Libora Assistant. Ask me about books, seats, hours or library rules.`);
    }
    renderAiSuggestions();
  } else {
    panel.classList.remove("show");
  }
}
function renderAiSuggestions(){
  document.getElementById("ai-suggest").innerHTML = AI_SUGGESTIONS.map(s=>`<button onclick="askAi('${s.replace(/'/g,"\\'")}')">${s}</button>`).join("");
}
function pushAiMessage(role, text){
  ui.aiHistory.push({role,text});
  const box = document.getElementById("ai-messages");
  const el = document.createElement("div");
  el.className = "ai-msg " + role;
  el.textContent = text;
  box.appendChild(el);
  box.scrollTop = box.scrollHeight;
}
function sendAiMessage(){
  const input = document.getElementById("ai-input");
  const text = input.value.trim();
  if(!text) return;
  input.value = "";
  askAi(text);
}
function askAi(text){
  pushAiMessage("user", text);
  const reply = answerAiQuery(text);
  setTimeout(()=>pushAiMessage("bot", reply), 320);
}
function answerAiQuery(q){
  const t = q.toLowerCase();

  if(/open|closed|hour|timing/.test(t)){
    return isLibraryOpen()
      ? `Yes — the library is open right now. Today's hours are 6:30 AM to 11:00 PM.`
      : `The library is currently closed. ${nextChangeLabel()}. Weekday hours are 6:30 AM–11:00 PM.`;
  }
  if(/seat|study spot|sit|space/.test(t)){
    const avail = DB.seats.filter(s=>!s.occupied).length;
    const byZone = [...new Set(DB.seats.map(s=>s.zone))].map(z=>{
      const n = DB.seats.filter(s=>s.zone===z && !s.occupied).length;
      return `${z}: ${n}`;
    }).join(", ");
    return `There are ${avail} seats free right now out of ${DB.seats.length}. By zone — ${byZone}. Open the Seat Map to reserve one.`;
  }
  if(/rule|policy|allowed|food|talk|quiet/.test(t)){
    return `Key rules: books are due in 14 days (up to 2 renewals if no one's waiting), the Silent Zone is no-talking, food is only allowed in the ground-floor café, and lost items are billed at replacement cost plus a $10 fee. See Library Info for the full list.`;
  }
  if(/wifi|wi-fi|internet/.test(t)){
    return `Wi-Fi is free campus-wide and available on all four floors — no login needed for enrolled students.`;
  }
  if(/contact|phone|email|address|where.*library/.test(t)){
    return `You can reach the library at (555) 213-4890 or library@ashcombe.edu. We're on the 2nd floor of the Library Building.`;
  }
  if(/overdue|fine|late/.test(t)){
    const mine = DB.borrows.filter(b=>b.userId===session.user.id && b.status!=="returned" && new Date(b.dueDate)<new Date());
    return mine.length ? `You currently have ${mine.length} overdue item${mine.length>1?'s':''}: ${mine.map(b=>DB.books.find(x=>x.id===b.bookId).title).join(", ")}. Please return or renew soon.` : `You have no overdue items right now — nicely done.`;
  }
  if(/my book|borrowed|what do i have/.test(t)){
    const mine = DB.borrows.filter(b=>b.userId===session.user.id && b.status!=="returned");
    return mine.length ? `You currently have ${mine.length} book${mine.length>1?'s':''} borrowed: ${mine.map(b=>DB.books.find(x=>x.id===b.bookId).title+" (due "+fmtDateShort(b.dueDate)+")").join(", ")}.` : `You don't have any books borrowed at the moment.`;
  }

  // book / topic search
  const catMatch = CATEGORIES.find(c=>t.includes(c.toLowerCase()));
  let matches = DB.books.filter(b=> t.includes(b.title.toLowerCase().split(' ')[0]) || b.title.toLowerCase().includes(t) || t.includes(b.author.toLowerCase().split(' ').pop()) );
  if(!matches.length){
    const words = t.replace(/[^a-z0-9 ]/g,'').split(' ').filter(w=>w.length>3);
    matches = DB.books.filter(b=> words.some(w=> b.title.toLowerCase().includes(w) || b.category.toLowerCase().includes(w) || b.description.toLowerCase().includes(w)) );
  }
  if(catMatch && !matches.length){
    matches = DB.books.filter(b=>b.category===catMatch);
  }
  if(matches.length){
    const top = matches.slice(0,3);
    const lines = top.map(b=>`“${b.title}” by ${b.author} — ${b.available>0?`${b.available} available, rack ${b.rack}·${b.shelf}`:'currently checked out'}`).join("; ");
    return `I found ${matches.length} match${matches.length>1?'es':''}: ${lines}. Open Search Books for full details.`;
  }

  return `I couldn't find a specific answer for that. Try asking about book availability, seats, library hours, or borrowing rules — or use Search Books for the full catalog.`;
}

/* ---------------- INIT ---------------- */
document.getElementById("login-email").addEventListener("keydown", e=>{ if(e.key==="Enter") handleLogin(); });
document.getElementById("login-password").addEventListener("keydown", e=>{ if(e.key==="Enter") handleLogin(); });
